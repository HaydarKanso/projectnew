package com.Kanso.EmployeeControlApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeControlAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
