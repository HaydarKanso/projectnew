package com.Kanso.EmployeeControlApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeeControlAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmployeeControlAppApplication.class, args);
	}

}
